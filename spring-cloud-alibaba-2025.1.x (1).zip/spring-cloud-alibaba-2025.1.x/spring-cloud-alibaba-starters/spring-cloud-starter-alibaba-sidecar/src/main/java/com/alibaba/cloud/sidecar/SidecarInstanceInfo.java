/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.alibaba.cloud.sidecar;

import java.util.Objects;

import org.jspecify.annotations.Nullable;

import org.springframework.boot.health.contributor.Status;

/**
 * @author yuhuangbin
 */
public class SidecarInstanceInfo {

	@Nullable
	private String ip;

	@Nullable
	private Integer port;

	@Nullable
	private Status status;

	@Nullable
	public String getIp() {
		return ip;
	}

	public void setIp(@Nullable String ip) {
		this.ip = ip;
	}

	@Nullable
	public Integer getPort() {
		return port;
	}

	public void setPort(@Nullable Integer port) {
		this.port = port;
	}

	@Nullable
	public Status getStatus() {
		return status;
	}

	public void setStatus(@Nullable Status status) {
		this.status = status;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) {
			return true;
		}
		if (o == null || getClass() != o.getClass()) {
			return false;
		}
		SidecarInstanceInfo that = (SidecarInstanceInfo) o;
		return Objects.equals(ip, that.ip) && Objects.equals(port, that.port)
				&& Objects.equals(status, that.status);
	}

	@Override
	public int hashCode() {
		return Objects.hash(ip, port, status);
	}

}
