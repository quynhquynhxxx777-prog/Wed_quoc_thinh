/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.alibaba.cloud.nacos.proxy.druid;

import com.alibaba.cloud.nacos.NacosConfigManager;

import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class NacosDruidFilterConfiguration {

	@Bean
	@ConditionalOnProperty(value = "spring.nacos.config.proxy.druid.enabled", havingValue = "true")
	@ConditionalOnBean(NacosConfigManager.class)
	public NacosDruidConfigFilter nacosDruidFilter(Environment environment) {
		String proxyDataId = environment.getProperty("spring.nacos.config.proxy.druid.data-id");
		if (proxyDataId == null) {
			throw new IllegalStateException("spring.nacos.config.proxy.druid.data-id is required");
		}
		return new NacosDruidConfigFilter(proxyDataId);
	}

}
