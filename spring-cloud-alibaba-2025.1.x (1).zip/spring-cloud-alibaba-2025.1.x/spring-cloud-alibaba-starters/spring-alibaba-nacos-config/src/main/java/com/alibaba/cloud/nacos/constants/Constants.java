/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.alibaba.cloud.nacos.constants;


/**
 * @author <a href="mailto:chiangzeon@gmail.com">chiangzeon</a>
 */
public final class Constants {

	private Constants() {
	}

	/**
	 * property:spring.config.import.
	 */
	public static final String SPRING_CONFIG_IMPORT_PROPERTIES = "spring.config.import";

	/**
	 * Yaml for nacos config files.
	 */
	public static final String NACOS_YAML_TYPE = "yaml";

	/**
	 * Yml for nacos config files.
	 */
	public static final String NACOS_YML_TYPE = "yml";

	/**
	 * Properties for nacos config files.
	 */
	public static final String NACOS_PROPERTIES_TYPE = "properties";

	/**
	 * status up .
	 */
	public static final String STATUS_UP = "UP";

	/**
	 * status down .
	 */
	public static final String STATUS_DOWN = "DOWN";

}
