/*
 * Copyright 2013-present the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.alibaba.cloud.sentinel.datasource.factorybean;

import com.alibaba.cloud.commons.lang.StringUtils;
import com.alibaba.csp.sentinel.datasource.Converter;
import com.alibaba.csp.sentinel.datasource.zookeeper.ZookeeperDataSource;
import org.jspecify.annotations.Nullable;

import org.springframework.beans.factory.FactoryBean;

/**
 * A {@link FactoryBean} for creating {@link ZookeeperDataSource} instance.
 *
 * @author <a href="mailto:fangjian0423@gmail.com">Jim</a>
 * @see ZookeeperDataSource
 */
public class ZookeeperDataSourceFactoryBean implements FactoryBean<ZookeeperDataSource> {

	private @Nullable String serverAddr;

	private @Nullable String path;

	private @Nullable String groupId;

	private @Nullable String dataId;

	private @Nullable Converter converter;

	@Override
	public ZookeeperDataSource getObject() throws Exception {
		if (StringUtils.isNotEmpty(groupId) && StringUtils.isNotEmpty(dataId)) {
			// the path will be /{groupId}/{dataId}
			if (serverAddr == null || groupId == null || dataId == null) {
				throw new IllegalStateException("serverAddr, groupId, and dataId must not be null");
			}
			return new ZookeeperDataSource(serverAddr, groupId, dataId, converter);
		}
		else {
			// using path directly
			if (serverAddr == null || path == null) {
				throw new IllegalStateException("serverAddr and path must not be null");
			}
			return new ZookeeperDataSource(serverAddr, path, converter);
		}
	}

	@Override
	public Class<?> getObjectType() {
		return ZookeeperDataSource.class;
	}

	public @Nullable String getServerAddr() {
		return serverAddr;
	}

	public void setServerAddr(@Nullable String serverAddr) {
		this.serverAddr = serverAddr;
	}

	public @Nullable String getPath() {
		return path;
	}

	public void setPath(@Nullable String path) {
		this.path = path;
	}

	public @Nullable String getGroupId() {
		return groupId;
	}

	public void setGroupId(@Nullable String groupId) {
		this.groupId = groupId;
	}

	public @Nullable String getDataId() {
		return dataId;
	}

	public void setDataId(@Nullable String dataId) {
		this.dataId = dataId;
	}

	public @Nullable Converter getConverter() {
		return converter;
	}

	public void setConverter(@Nullable Converter converter) {
		this.converter = converter;
	}

}
